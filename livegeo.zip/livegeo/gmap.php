<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
  <title></title>
  <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/combo?2.8.0/build/reset-fonts-grids/reset-fonts-grids.css&2.8.0/build/base/base-min.css">
</head>
<body class="yui-skin-sam">
<div id="doc" class="yui-t7">

  <div id="hd" role="banner">
    <h1></h1>
  </div>
  <div id="bd" role="main">
    <div id="map_canvas" style="width: 800px; height: 600px"></div>
  </div>
  <div id="ft" role="contentinfo">
    <p></p>
  </div>
    <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=true_or_false&amp;key=ABQIAAAAijZqBZcz-rowoXZC1tt9iRT2yXp_ZAY8_ufC3CFXhHIE1NvwkxQQBCaF1R_k1GBJV5uDLhAKaTePyQ" type="text/javascript"></script>
    <script type="text/javascript" charset="utf-8">
      var bounds = null;
      var map = new GMap2(document.getElementById("map_canvas"));
      map.setUIToDefault();
      
<?php
require_once 'SimpleGeo.php';
$client = new Services_SimpleGeo('RUc9ca6sU8vMJ4CGcCd272u5psaTsCPw', 'EtZXfduMwKc3bCmAbz9d8pbJtWmfZrz5');
$source1 = $_GET["source1"];
$source2 = $_GET["source2"];
$url_query = str_ireplace(" ","%20","$source1");
$url_yahoofinder = "http://where.yahooapis.com/v1/places.q(".""."$url_query"."".")?appid=R3uEZcjV34FcVcdijSJakINk9bhElP4V4YqM5sNthFx.12Up8j.8sahnPUkDFvxkG0c-";
$xml = simplexml_load_file("$url_yahoofinder");
$lat = $xml->children()->place->centroid->latitude;
$long1 = $xml->children()->place->centroid->longitude;

$url_query2 = str_ireplace(" ","%20","$source2");
$url_yahoofinder2 = "http://where.yahooapis.com/v1/places.q(".""."$url_query2"."".")?appid=R3uEZcjV34FcVcdijSJakINk9bhElP4V4YqM5sNthFx.12Up8j.8sahnPUkDFvxkG0c-";
$xml2 = simplexml_load_file("$url_yahoofinder2");
$lat_src2 = $xml2->children()->place->centroid->latitude;
$long1_src2 = $xml2->children()->place->centroid->longitude;

$day1=$_GET["day1"];
$day2=$_GET["day2"];
$hour1=$_GET["hour1"];
$hour2=$_GET["hour2"];
//$day1="mon";
//$day2="mon";
$i=0;
do
{
//$del_long=0.001373;
//$del_lat=0.005329;
$del_long=0.005373;
$del_lat=0.009329;
$lat1=(float)$lat+(float)$del_lat;
$long2=(float)$long1-(float)$del_long;
$lat12=(float)$lat+(float)$del_lat/4;
$long21=(float)$long1-(float)$del_long/4;
$data=($client->getRank($day1,$hour1,$lat,$long1));
$data_src2=($client->getRank($day2,$hour2,$lat_src2,$long1_src2));
$data1=print_r($data,true);
$data2=print_r($data_1,true);
$data_s2=print_r($data_src2,true);
$k=$data1.$data_s2;
preg_match_all('/(|-)\d+\.\d+/',$k,$keywords);
$i=0;$j=1;

function parseInt($string) {
if(preg_match('/(\d+)/', $string, $array)) {
return $array[1];
} else {
return 0;
}
} 

preg_match_all("/(local_rank)....../",$k,$ranks);
$i1=0;
foreach($ranks as $rk) {
if($rk[$i1])
{ 
$rank1=parseInt($rk[$i1]);//$i1++;
$rank2=parseInt(++$rk[$i1]);
break;
}
}
echo 'bounds = new GLatLngBounds();';
foreach($keywords as $latlong) {
while($latlong[$i])
{
echo 'var point=new GLatLng('.$latlong[$i].','.$latlong[$j].');';
//echo 'map.setCenter(new GLatLng('.$lat.', '.$long1.'), 13);';
//echo 'bounds = new GLatLngBounds();';
echo 'bounds.extend(point);';
echo 'map.setCenter(bounds.getCenter(), map.getBoundsZoomLevel(bounds));';
echo 'map.addOverlay(new GMarker(point));';
//echo 'map.addOverlay(new GMarker(point,{title:"'.$e->name.'"}));';
$i=$i+2;$j=$j+2;
}
if($rank1>$rank2)
{
//echo 'map.openInfoWindowHtml(map.getCenter(),document.createTextNode("'.$source1.''.$rank1.'\nis more populated than'.$rank2.'"));';
echo 'map.openInfoWindow(map.getCenter(),"'.$source1.':'.$rank1.'<br>is more populated than<br>'.$source2.':'.$rank2.'");';
}

if($rank1<$rank2)
{
//echo 'map.openInfoWindowHtml(map.getCenter(),document.createTextNode("'.$source1.''.$rank1.'\nis more populated than'.$rank2.'"));';
echo 'map.openInfoWindow(map.getCenter(),"'.$source2.':'.$rank2.'<br>is more populated than<br>'.$source1.':'.$rank1.'");';
}


if($rank1==$rank2)
{
//echo 'map.openInfoWindowHtml(map.getCenter(),document.createTextNode("'.$source1.''.$rank1.'\nis more populated than'.$rank2.'"));';
echo 'map.openInfoWindow(map.getCenter(),"'.$source1.':'.$rank1.'<br>has a similar trend<br>'.$source2.':'.$rank2.'");';
}

}
} while($i++<3);
?>      

          </script>
    
</div>
</body>
</html>
